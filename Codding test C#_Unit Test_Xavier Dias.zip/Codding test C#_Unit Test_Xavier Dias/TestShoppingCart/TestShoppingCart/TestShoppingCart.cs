﻿/**
 * Created date: 28/08/2016
 * Created By: Xavier Dias
 * Description: Test automation framework for testing Shopping cart using NUNIT and Selenium Web Driver
 * Limitations: Data driven testing component needs to be added
 * Note: The NUNIT framwork/adapter has some compatibility issue with VS 2013 express. 
 * Therefore no tests were displayed in the TesExplorer window, so errors can be expected in TestShoppingCart.cs.   
 * **/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace TestShoppingCart
{   
    [TestFixture]
    public class TestShoppingCart
    {
        //instantiate chrome  web driver and nevigate to the URL
        [SetUp]
        public void Initialize()
        {
            IWebDriver driver = new ChromeDriver();
            driver.Navigate().GoToUrl("http://localhost/ShoppingCart/shoppingcart.aspx");
            SCPageObjects page = new SCPageObjects();
        }

        //few test casses for testing Add Apples to cart functionality 
        [TestCase("Apples","1")]
        [TestCase("Apples", "3")]
        [TestCase("Apples", "-999")]
        [TestCase("Apples", "0")]
        [TestCase("Apples", "\u00A3")]
        [TestCase("Apples", "x")]
        public void TestAddApples(string item,string qty)
        {
            SCPageObjects page = new SCPageObjects();//create page object
            page.ddlItemsId.SendKeys(item);//Step1: select Apples from dropdown
            page.txtQuantityId.SendKeys(qty);//Step2: enter quantity into textbox
            page.btnAddtocartId.Click();//step3: click on addtocart button
            if (int.Parse(qty) == 1)
            {
                Assert.AreEqual("Total cost of 1 item is 60p", SeleniumGetMethods.GetLabelText("lbl_btn_msg", PropertyTypes.Id));

            }
            else if (int.Parse(qty) > 0)
            {
                double value = int.Parse(qty) * 0.6;
                Assert.AreEqual(string.Format("Total cost of {0} items is £ {1}", qty, value), SeleniumGetMethods.GetLabelText("lbl_btn_msg", PropertyTypes.Id));
            }
            else
                Assert.AreEqual("Please enter a valid quantity of items", SeleniumGetMethods.GetLabelText("lbl_qty_msg", PropertyTypes.Id));

        }

        //few test casses for testing Add Orange to cart functionality 
        [TestCase("Oranges", "4")]
        [TestCase("Oranges", "3")]
        [TestCase("Oranges", "-999")]
        [TestCase("Oranges", "0")]
        [TestCase("Oranges", "\u00A3")]
        [TestCase("Oranges", "x")]
        public void TestAddOranges(string item, string qty)
        {
            SCPageObjects page = new SCPageObjects();//create page object
            page.ddlItemsId.SendKeys(item);//Step1: select Apples from dropdown
            page.txtQuantityId.SendKeys(qty);//Step2: enter quantity into textbox
            page.btnAddtocartId.Click();//step3: click on addtocart button
            if (int.Parse(qty) <= 3)
            {
                double value = int.Parse(qty) * 0.25;
                Assert.AreEqual(string.Format("Total cost of {0} items is {1}p",qty,value), SeleniumGetMethods.GetLabelText("lbl_btn_msg", PropertyTypes.Id));
            }
            else if (int.Parse(qty) > 0)
            {
                double value = int.Parse(qty) * 0.25;
                Assert.AreEqual(string.Format("Total cost of {0} items is £ {1}", qty, value), SeleniumGetMethods.GetLabelText("lbl_btn_msg", PropertyTypes.Id));
            }
            else
                Assert.AreEqual("Please enter a valid quantity of items", SeleniumGetMethods.GetLabelText("lbl_qty_msg", PropertyTypes.Id));
        }

        //Test Reset button funtionality
        [Test]
        public void Reset()
        {
            SCPageObjects page = new SCPageObjects();
            page.btnResetId.Click();//Click the reset button
            Assert.AreEqual("Apples", SeleniumGetMethods.GetDropDownText("dd_items", PropertyTypes.Id));
            Assert.AreEqual("", SeleniumGetMethods.GetText("txt_quantity", PropertyTypes.Id));
            Assert.AreEqual("", SeleniumGetMethods.GetLabelText("lbl_btn_msg", PropertyTypes.Id));
            Assert.AreEqual("", SeleniumGetMethods.GetLabelText("lbl_qty_msg", PropertyTypes.Id));
        }

        [TearDown]
        public void CleanUp()
        {
            SCProperties.driver.Close();
        }
    }
}
