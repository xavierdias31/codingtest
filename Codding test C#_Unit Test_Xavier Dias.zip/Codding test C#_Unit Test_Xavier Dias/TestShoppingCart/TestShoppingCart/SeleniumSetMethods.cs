﻿/**
 * Created date: 28/08/2016
 * Created By: Xavier Dias
 * Description: Generic contol set methods for test framework
 * Limitations: The methods can be made more generic
* **/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;


namespace TestShoppingCart
{
    class SeleniumSetMethods
    {       //Method for entering data in a text box
            public static void EnterText(string element, string value, PropertyTypes elementtype)
            {
                try
                {
                    if (elementtype == PropertyTypes.Id)//element type is ID
                    {
                        SCProperties.driver.FindElement(By.Id(element)).SendKeys(value);
                    }
                    if (elementtype == PropertyTypes.Name)//Element type is name
                    {
                        SCProperties.driver.FindElement(By.Name(element)).SendKeys(value);
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("Exception: {0}", e);
                }
            }
        //for clicking on an element
            public static void Click(string element, PropertyTypes elementtype)
            {
                try
                {
                    if (elementtype == PropertyTypes.Id)//element type is ID
                    {
                        SCProperties.driver.FindElement(By.Id(element)).Click();
                    }
                    if (elementtype == PropertyTypes.Name)//Element type is name
                    {
                        SCProperties.driver.FindElement(By.Name(element)).Click();
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("Exception: {0}", e);
                }

            }
        //for selecing a dropdown list item
            public static void SelectDropDown(string element, string value, PropertyTypes elementtype)
            {
                try
                {
                    if (elementtype == PropertyTypes.Id)
                    {
                        new SelectElement(SCProperties.driver.FindElement(By.Id(element))).SelectByText(value);
                    }
                    if (elementtype == PropertyTypes.Name)
                    {
                        new SelectElement(SCProperties.driver.FindElement(By.Name(element))).SelectByText(value);
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine("Exception: {0}", e);
                }
            }
        }
    }

