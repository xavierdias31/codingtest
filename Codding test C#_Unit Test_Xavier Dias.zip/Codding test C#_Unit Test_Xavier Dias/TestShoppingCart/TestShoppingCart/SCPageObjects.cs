﻿/**
 * Created date: 28/08/2016
 * Created By: Xavier Dias
 * Description: PageObject pattern for test framework
 * Limitations: more objects can be added
* **/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Support.PageObjects;

namespace TestShoppingCart
{
    class SCPageObjects
    {
        public SCPageObjects()
        {
            PageFactory.InitElements(SCProperties.driver, this);//initialize elements using selenium pagefactory
        }

        [FindsBy(How = How.Id, Using = "dd_items")]
        public IWebElement ddlItemsId { get; set; }

        [FindsBy(How = How.Id, Using = "txt_quantity")]
        public IWebElement txtQuantityId { get; set; }

        [FindsBy(How = How.Id, Using = "btn_addtocart")]
        public IWebElement btnAddtocartId { get; set; }

        [FindsBy(How = How.Id, Using = "btn_reset")]
        public IWebElement btnResetId { get; set; }
        
    }
}
