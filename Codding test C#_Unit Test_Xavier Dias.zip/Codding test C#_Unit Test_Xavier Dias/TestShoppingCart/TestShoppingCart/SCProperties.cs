﻿/**
 * Created date: 28/08/2016
 * Created By: Xavier Dias
 * Description: This class sets driver properties and create property types
 * Limitations: Can handle more items in enum
* **/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace TestShoppingCart
{
    enum PropertyTypes//enumeration for commom element identifiers
    {
        Id,
        Name,
        CssName,
        LinkText,
        ClassName
    }
    class SCProperties
    {
        public static IWebDriver driver { get; set; }//create auto implimented property for driver
    }
}
