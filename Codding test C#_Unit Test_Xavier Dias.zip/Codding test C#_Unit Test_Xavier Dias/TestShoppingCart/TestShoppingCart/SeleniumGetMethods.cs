﻿/**
 * Created date: 28/08/2016
 * Created By: Xavier Dias
 * Description: Generic contol get methods for test framework
 * Limitations: The methods can be made more generic
* **/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace TestShoppingCart
{
    class SeleniumGetMethods
    {
        public static string GetText( string element, PropertyTypes elementtype)
        {
            try 
            { 
                if (elementtype == PropertyTypes.Id)
                {
                    return SCProperties.driver.FindElement(By.Id(element)).GetAttribute("value");
                }
                if (elementtype == PropertyTypes.Name)
                {
                    return SCProperties.driver.FindElement(By.Id(element)).GetAttribute("value");
                }
                else return string.Empty;
            }
            catch (Exception e)
            {
                return string.Format("Exception: {0}", e);
            }
        }
    

        public static string GetDropDownText( string element, PropertyTypes elementtype)
        {
            try
            {
                if (elementtype == PropertyTypes.Id)
                {
                    return new SelectElement(SCProperties.driver.FindElement(By.Id(element))).AllSelectedOptions.SingleOrDefault().Text;
                }
                if (elementtype == PropertyTypes.Name)
                {
                    return new SelectElement(SCProperties.driver.FindElement(By.Name(element))).AllSelectedOptions.SingleOrDefault().Text;
                }
                else return string.Empty;
            }
            catch(Exception e)
            {
                return string.Format("Exception: {0}", e);
            }
        }

        public static string GetLabelText(string element, PropertyTypes elementtype)
        {
            try
            {
                if (elementtype == PropertyTypes.Id)
                {
                    IWebElement labelElement = SCProperties.driver.FindElement(By.Id(element));
                    IJavaScriptExecutor js = SCProperties.driver as IJavaScriptExecutor;
                    if (js != null)
                    {
                        return (string)js.ExecuteScript("return arguments[0].innerHTML;", labelElement);
                    }
                }
                if (elementtype == PropertyTypes.Name)
                {
                    SCProperties.driver.FindElement(By.Name(element));
                    IJavaScriptExecutor js = SCProperties.driver as IJavaScriptExecutor;
                    if (js != null)
                    {
                        return (string)js.ExecuteScript("return arguments[0].innerHTML;", element);
                    }
                    else return string.Empty;
                }
                else return string.Empty;
            }
            catch (Exception e)
            {
                return string.Format("Exception: {0}", e);
            }
        }
    }
}
