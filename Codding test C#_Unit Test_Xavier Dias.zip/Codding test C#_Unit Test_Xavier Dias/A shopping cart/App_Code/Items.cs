﻿/**
 * Created date: 28/08/2016
 * Created By: Xavier Dias
 * Description: The Items class with properties and constructor
 * Limitations: scope for more fuctionality
* **/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Items
/// </summary>
public class Items
{  
	private string name;
    private double cost;
    private int quantity;

    public string Name
    {
        get{return name;}
        set{name=value;}
    }

    public double Cost
    {
        get { return cost; }
        set { cost = value; }
    }
    public int Quanity
    {
        get { return quantity; }
        set {quantity = value;}

    }
    public Items(string name, int quantity, double cost)
    {
        this.name = name;
        this.cost = cost;
        this.quantity = quantity;
    }

}
