﻿/**
 * Created date: 28/08/2016
 * Created By: Xavier Dias
 * Description: A shopping cart application that can add Apples @60p and Oranges @25p to cart and total
 * Limitations: Code can be reorganized
* **/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class shoppingcart : System.Web.UI.Page
{//initializes the static variables
    static double totalCost = 0.00;
    static int qty = 0;
    protected void Page_Load(object sender, EventArgs e)//clears lables on page load
    {
        lbl_btn_msg.Text = "";
        lbl_qty_msg.Text = "";
    }
    protected void btn_addtocart_Click(object sender, EventArgs e)//add items (apples and oranges)
    {
        try
        {
            int quantity;
            bool isInt = int.TryParse(txt_quantity.Text, out quantity);//validates text box values for positive integers
            if (quantity < 1 || isInt == false)
            {
                lbl_qty_msg.Text = "Please enter a valid quantity of items.";
            }
            else
            {
                if (dd_items.Text == "Apples")
                {
                    Items Apple = new Items("Apples", quantity, 0.60);
                    AddToCart(ref Apple);//invokes AddToCart method to calculate cost of apples
                }
                else if (dd_items.Text == "Oranges")
                {
                    Items Orange = new Items("Oranges", quantity, 0.25);
                    AddToCart(ref Orange);//invokes AddToCart method to calculate cost of oranges
                }
            }
        }
        catch (Exception ex)
        {
            lbl_qty_msg.Text = string.Format("An error occured: '{0}'", ex.Message);
        }

    }
    public void AddToCart(ref Items fruits)//calculates fruit cost
    {
        try
        {
            qty += fruits.Quanity;
            totalCost += fruits.Quanity * fruits.Cost;

            if (fruits.Name == "Apples" && qty == 1)
            {
               lbl_btn_msg.Text = string.Format("Total cost of {0} item is {1}p\n", qty, 60);
            }
            else if (fruits.Name == "Oranges" && qty < 4 && totalCost < 1)
            {
                lbl_btn_msg.Text = string.Format("Total cost of {0} items is {1}p \n", qty, totalCost.ToString());
            }
            else
            {
                lbl_btn_msg.Text = string.Format("Total cost of {0} items is \u00A3 {1} \n", qty, totalCost.ToString());
            }
        }
        catch (Exception ex)
        {
            lbl_qty_msg.Text = string.Format("An error occured: '{0}'", ex.Message);
        }

    }
    //reset the controls
    protected void btn_reset_Click(object sender, EventArgs e)
    {
        totalCost = 0.00;
        qty = 0;
        lbl_btn_msg.Text = "";
        lbl_qty_msg.Text = "";
        txt_quantity.Text = "";
        dd_items.SelectedValue = "Apples";
    }
}